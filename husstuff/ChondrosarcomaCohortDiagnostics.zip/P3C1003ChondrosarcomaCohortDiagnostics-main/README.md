
<!-- README.md is generated from README.Rmd. Please edit that file -->

# P3C1003ChondrosarcomaCohortDiagnostics

<!-- badges: start -->

[![R-CMD-check](https://github.com/darwin-eu-studies/P3-C1-003-Chondrosarcoma-CohortDiagnostics/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/darwin-eu-studies/P3-C1-003-Chondrosarcoma-CohortDiagnostics/actions/workflows/R-CMD-check.yaml)
<!-- badges: end -->

# 1. Instructions

A
[CodeToRun.R](https://github.com/darwin-eu-studies/P3C1003ChondrosarcomaCohortDiagnostics/tree/main/extras)
file is provided in the “extras” directory as an example of how to run
this package. Below you will find 2 sections: the 1st is for installing
the study package and its dependencies, the 2nd for running the package.

In section 2 below, you will also need to update the code to use your
site specific values.

# Installation

1.  See the instructions at <https://ohdsi.github.io/Hades/rSetup.html>
    for configuring your R environment, including Java and RStudio.

2.  Download this package, build, install and run it in the same
    directory.

3.  Execute the following R code for the environment:

# Install the latest version of renv:

``` r
install.packages("renv")
```

# Build the local library. This may take a while:

``` r
renv::init()
```

# Restore the library

``` r
renv::restore()
```

# 2. Running the package

Edit the variables below to the correct values for your environment:

``` r
library(P3C1003ChondrosarcomaCohortDiagnostics)

# Login details
dbms <- Sys.getenv("dbms")
host <- Sys.getenv("host")
dbname <- Sys.getenv("dbname")
user <- Sys.getenv("user")
password <- Sys.getenv("password")
port <- Sys.getenv("port")

connectionDetails <- DatabaseConnector::createConnectionDetails(dbms = dbms,
                                                                server = paste0(host, "/", dbname),
                                                                user = user,
                                                                password = password,
                                                                port = port)

connection <- DatabaseConnector::connect(connectionDetails)

# A folder on the local file system to store results:
outputDir <- "..."

# The database schema where the observational data in CDM is located.

cdmDatabaseSchema <- "..."

# The database schema where the cohorts can be instantiated.
cohortDatabaseSchema <- "..."


# The name of the table that will be created in the cohortDatabaseSchema.
cohortTable <- "..."

# The databaseId is a short (<= 20 characters)
databaseId <- "..."

# This statement instatiates the cohorts, performs the diagnostics, and writes the results to
# a zip file containing CSV files. This will probaby take a long time to run:
P3C1003ChondrosarcomaCohortDiagnostics::runDiagnostics(
  connectionDetails = connectionDetails,
  cdmDatabaseSchema = cdmDatabaseSchema,
  vocabularyDatabaseSchema = cdmDatabaseSchema,
  cohortDatabaseSchema = cohortDatabaseSchema,
  cohortTable = cohortTable,
  outputDir = outputDir,
  databaseId = databaseId
)

# (Optionally) to view the results locally:
CohortDiagnostics::createMergedResultsFile(
  dataFolder = file.path(outputDir),
  sqliteDbPath = file.path(outputDir, "MergedCohortDiagnosticsData.sqlite")
)
CohortDiagnostics::launchDiagnosticsExplorer(sqliteDbPath = file.path(outputDir, "MergedCohortDiagnosticsData.sqlite"))
```

# 3. Upload the results to the DTZ

Please upload the zip file with results to the Data Transfer Zone (DTZ)
under the study folder P2-C1-003.

``` r

# Results_Chondrosarcoma_{Data Partner Name}_current_date.zip
```
