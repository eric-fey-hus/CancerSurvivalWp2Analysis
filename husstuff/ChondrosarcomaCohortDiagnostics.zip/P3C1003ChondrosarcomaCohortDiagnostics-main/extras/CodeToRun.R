
# *******************************************************
# -----------------INSTRUCTIONS -------------------------
# *******************************************************
#
# This CodeToRun.R is provided as an example of how to run this study package.
#
# Below you will find 3 sections: the 1st is for installing the study package and its dependencies,
# the 2nd for running the package, the 3rd is for sharing the results with the study coordinator.
#
# In section 2 below, you will also need to update the code to use your site specific values. Please scroll
# down for specific instructions.
#
#
# *******************************************************
# SECTION 1: Installing
# *******************************************************
#
# 1. Execute the following R code:

# Install the latest version of renv:
install.packages("renv")

# Build the local library. This may take a while:
renv::init()
# Restore the library
renv::restore()

# *******************************************************
# SECTION 2: Running the package -------------------------------------------------------------------------------
# *******************************************************
#
# Edit the variables below to the correct values for your environment:

library(P3C1003ChondrosarcomaCohortDiagnostics)

# Login details
dbms <- Sys.getenv("dbms")
host <- Sys.getenv("host")
dbname <- Sys.getenv("dbname")
user <- Sys.getenv("user")
password <- Sys.getenv("password")
port <- Sys.getenv("port")

connectionDetails <- DatabaseConnector::createConnectionDetails(dbms = dbms,
                                                                server = paste0(host, "/", dbname),
                                                                user = user,
                                                                password = password,
                                                                port = port)

connection <- DatabaseConnector::connect(connectionDetails)

# A folder on the local file system to store results:
outputDir <- "..."

# The database schema where the observational data in CDM is located.

cdmDatabaseSchema <- "..."

# The database schema where the cohorts can be instantiated.
cohortDatabaseSchema <- "..."


# The name of the table that will be created in the cohortDatabaseSchema.
cohortTable <- "..."

# The databaseId is a short (<= 20 characters)
databaseId <- "..."

# This statement instatiates the cohorts, performs the diagnostics, and writes the results to
# a zip file containing CSV files. This will probaby take a long time to run:
P3C1003ChondrosarcomaCohortDiagnostics::runDiagnostics(
  connectionDetails = connectionDetails,
  cdmDatabaseSchema = cdmDatabaseSchema,
  vocabularyDatabaseSchema = cdmDatabaseSchema,
  cohortDatabaseSchema = cohortDatabaseSchema,
  cohortTable = cohortTable,
  outputDir = outputDir,
  databaseId = databaseId
)

outputDir <- "results"

# (Optionally) to view the results locally:
CohortDiagnostics::createMergedResultsFile(
  dataFolder = file.path(outputDir),
  sqliteDbPath = file.path(outputDir, "MergedCohortDiagnosticsData.sqlite"),
  overwrite = TRUE
)
CohortDiagnostics::launchDiagnosticsExplorer(sqliteDbPath = file.path(outputDir, "MergedCohortDiagnosticsData.sqlite"))
