CREATE TABLE #Codesets (
  codeset_id int NOT NULL,
  concept_id bigint NOT NULL
)
;

INSERT INTO #Codesets (codeset_id, concept_id)
SELECT 0 as codeset_id, c.concept_id FROM (select distinct I.concept_id FROM
( 
  select concept_id from @vocabulary_database_schema.CONCEPT where concept_id in (45771369,40481938,40486574,607436,607437,607434,607435,607438,607433,3179838,607439,45773107,45766523,36534641,36523756,42511630,42512935,36524031,36551284,44499912,36533603,36550660,36535191,36551471,42512383,36529266,36537890,42511882,36518305,36538559,36527602,44501747,36545965,44499586,36540261,36526411,36520352,36547692,36563462,44502056,36548029,36518039,44499598,36549873,36527279,36544650,42512891,36541137,36529737,36532862,36565610,42512428,36535535,36532068,36529826,36534535,36546085,36533147,36531275,36522901,36554271,36529504,36546977,36564901,36559448,36538017,44503177,36526470,36557249,36538913,36535268,36551347,36556860,36535371,36518500,36563136,44502133,36519748,44501863,4028692,36534545,36535201,36564258,36526737,36564132,36556686,36526745,36522616,36533886,36527978,36526660,36539180,42511684,36535683,36564835,36537788,36537195,36564498,36538216,36518295,36530851,36552197,36556938,36559564,36541972,36520663,36550393,36527454,36525914,36541718,36535736,36523751,37207682,35954150,4029031,36541913,36547961,36527824,36562329,36551597,36534710,36558682,36519746,36547274,36556041,36545734,36544020,36530319,36521865,36539340,36549870,36553941,36562669,36534973,36549134,36545787,36563241,36559047,36529873,36530294,36526712,36534410,36563608,36541869,36524419,36561917,37207535,4297346,4297345,3655298,4094509,4209580,36567464,36537160,36526302,36558815,36522746,36529880,36532686,36547128,36541806,36526673,36553616,36538170,36530577,36561252,36523867,36555967,36554653,36561410,36520760,44501291,36558448,36535126,730576,36559413,36554862,36521506,36558095,36549191,44501105,36549848,36558215,36556153,36535054,36553329,36552040,36556462,36523227,42512942,36565209,36526023,36562445,36531428,36548053,36557713,37207540,4328092,36557238,36544751,36549378,44502584,36531230,36567516,36529383,36563461,36529095,36561941,36533470,36535870,42512852,36540963,36542064,42512923,36556500,36547671,36557726,36531067,36540285,36561481,42511997,44500820,36533058,36534364,36548525,44502736,44503049,42513751,42513752,42513749,42513748,42513744,2102793,36558653,36541445,36544561,36520008,36538806,36544844,36540974,36533938,36534232,36547380,36539588,36563361,36547009,36553907,36530596,36519044,36562042,36561619,36565377,36545603,36544240,42539037,37109898,37109899,37109900,42539556,602670,602671,602672,602669,37109897,37018647,37018646,37119229,602153,602154,602155,602152,37018644,602673,602036,602674,609187,602037)

) I
) C UNION ALL 
SELECT 1 as codeset_id, c.concept_id FROM (select distinct I.concept_id FROM
( 
  select concept_id from @vocabulary_database_schema.CONCEPT where concept_id in (443392,4162276,42596197,4301780,258981,4291595,4111948,4301779,4291293,4110733,40489940)
UNION  select c.concept_id
  from @vocabulary_database_schema.CONCEPT c
  join @vocabulary_database_schema.CONCEPT_ANCESTOR ca on c.concept_id = ca.descendant_concept_id
  and ca.ancestor_concept_id in (443392,4162276,42596197,4301780,258981,4291595,4111948,4301779,4291293,4110733,40489940)
  and c.invalid_reason is null

) I
LEFT JOIN
(
  select concept_id from @vocabulary_database_schema.CONCEPT where concept_id in (433435,42514272,42514300,42514069,42514087,42514220,42514355,42514250,42514287,42514264,42514252,42514189,42514379,42514157,42514198,42514109,42514206,42514341,42514251,42514168,42514350,42514129,42514102,42514156,42514291,42514378,42514367,42514217,42514165,42514372,42514202,42514326,42514143,42514304,42514373,42514103,42514334,42514256,42514182,42514239,42514278,42514362,42514093,42514097,42514376,42514163,42514297,42514369,42514363,42514178,42514307,42514214,42514288,42514208,42514263,42514201,42514303,42514290,42514100,42514327,42514329,42514254,42514294,42514170,42514147,42514104,42514374,42514126,42514199,42514338,42514173,42514315,42514225,42514277,42514231,42514108,42514091,42514232,42514260,42514302,42514191,42514365,42514136,42514237,42514325,42514337,42514359,42514110,42514324,42514228,42514098,42514048,42514137,42514218,42514125,42514080,42514209,42514357,42514348,42514335,42514305,42512800,42511869,42512038,42511724,42511824,42511643,42512747,42512286,42512532,42512028,42513173,42513168,42512981,42511959,42512883,42512099,42512152,42512086,42512566,42512846,42512691,36403050,36403028,36403071,36402997,36403059,36403077,36403012,36402991,36403070,36403044,36403007,36403014,36403066,36403006,36403031,36403020,36403061,36403004,36403009,36403056,36403010,36403042,36403046,36403036,36403143,36403115,36403083,36403138,36403141,36403128,36403152,36403107,36403090,36403132,36403091,36403142,36403134,36403148,36403120,36403095,36403112,36403093,36403139,36403145,36403109,36403149,36403081,36403026,36403058,36403034,36402992,36403054,36403041,36403043,36403073,36403030,36403024,36403117,36403102,36402628,36403078,36402440,36403047,36403129,36403013,36403049,36403029,36403032,36403017,36403027,36403025,36402993,36403064,36403075,36402451,36402490,36402587,36402471,36403151,36403082,36403123,36403080,36402645,36403076,36403068,36403039,36403033,36403057,36403001,36403069,36403072,36403003,36403048,36403086,36403154,36402417,36402373,36402391,36402644,606916,3171629,4031105,42514180,42514169,42514212,42514175,42514215,42514107,3177900,4112752,4155297)
UNION  select c.concept_id
  from @vocabulary_database_schema.CONCEPT c
  join @vocabulary_database_schema.CONCEPT_ANCESTOR ca on c.concept_id = ca.descendant_concept_id
  and ca.ancestor_concept_id in (433435,42514272,42514300,42514069,42514087,42514220,42514355,42514250,42514287,42514264,42514252,42514189,42514379,42514157,42514198,42514109,42514206,42514341,42514251,42514168,42514350,42514129,42514102,42514156,42514291,42514378,42514367,42514217,42514165,42514372,42514202,42514326,42514143,42514304,42514373,42514103,42514334,42514256,42514182,42514239,42514278,42514362,42514093,42514097,42514376,42514163,42514297,42514369,42514363,42514178,42514307,42514214,42514288,42514208,42514263,42514201,42514303,42514290,42514100,42514327,42514329,42514254,42514294,42514170,42514147,42514104,42514374,42514126,42514199,42514338,42514173,42514315,42514225,42514277,42514231,42514108,42514091,42514232,42514260,42514302,42514191,42514365,42514136,42514237,42514325,42514337,42514359,42514110,42514324,42514228,42514098,42514048,42514137,42514218,42514125,42514080,42514209,42514357,42514348,42514335,42514305,42512800,42511869,42512038,42511724,42511824,42511643,42512747,42512286,42512532,42512028,42513173,42513168,42512981,42511959,42512883,42512099,42512152,42512086,42512566,42512846,42512691,36403050,36403028,36403071,36402997,36403059,36403077,36403012,36402991,36403070,36403044,36403007,36403014,36403066,36403006,36403031,36403020,36403061,36403004,36403009,36403056,36403010,36403042,36403046,36403036,36403143,36403115,36403083,36403138,36403141,36403128,36403152,36403107,36403090,36403132,36403091,36403142,36403134,36403148,36403120,36403095,36403112,36403093,36403139,36403145,36403109,36403149,36403081,36403026,36403058,36403034,36402992,36403054,36403041,36403043,36403073,36403030,36403024,36403117,36403102,36402628,36403078,36402440,36403047,36403129,36403013,36403049,36403029,36403032,36403017,36403027,36403025,36402993,36403064,36403075,36402451,36402490,36402587,36402471,36403151,36403082,36403123,36403080,36402645,36403076,36403068,36403039,36403033,36403057,36403001,36403069,36403072,36403003,36403048,36403086,36403154,36402417,36402373,36402391,36402644,606916,3171629,4031105,42514180,42514169,42514212,42514175,42514215,42514107,3177900,4112752,4155297)
  and c.invalid_reason is null

) E ON I.concept_id = E.concept_id
WHERE E.concept_id is null
) C;

UPDATE STATISTICS #Codesets;


SELECT event_id, person_id, start_date, end_date, op_start_date, op_end_date, visit_occurrence_id
INTO #qualified_events
FROM 
(
  select pe.event_id, pe.person_id, pe.start_date, pe.end_date, pe.op_start_date, pe.op_end_date, row_number() over (partition by pe.person_id order by pe.start_date ASC) as ordinal, cast(pe.visit_occurrence_id as bigint) as visit_occurrence_id
  FROM (-- Begin Primary Events
select P.ordinal as event_id, P.person_id, P.start_date, P.end_date, op_start_date, op_end_date, cast(P.visit_occurrence_id as bigint) as visit_occurrence_id
FROM
(
  select E.person_id, E.start_date, E.end_date,
         row_number() OVER (PARTITION BY E.person_id ORDER BY E.sort_date ASC, E.event_id) ordinal,
         OP.observation_period_start_date as op_start_date, OP.observation_period_end_date as op_end_date, cast(E.visit_occurrence_id as bigint) as visit_occurrence_id
  FROM 
  (
  -- Begin Condition Occurrence Criteria
SELECT C.person_id, C.condition_occurrence_id as event_id, C.start_date, C.end_date,
  C.visit_occurrence_id, C.start_date as sort_date
FROM 
(
  SELECT co.person_id,co.condition_occurrence_id,co.condition_concept_id,co.visit_occurrence_id,co.condition_start_date as start_date, COALESCE(co.condition_end_date, DATEADD(day,1,co.condition_start_date)) as end_date , row_number() over (PARTITION BY co.person_id ORDER BY co.condition_start_date, co.condition_occurrence_id) as ordinal
  FROM @cdm_database_schema.CONDITION_OCCURRENCE co
  JOIN #Codesets cs on (co.condition_concept_id = cs.concept_id and cs.codeset_id = 0)
) C

WHERE (C.start_date >= DATEFROMPARTS(2010, 1, 1) and C.start_date <= DATEFROMPARTS(2022, 12, 31))
AND C.ordinal = 1
-- End Condition Occurrence Criteria

UNION ALL
-- Begin Observation Criteria
select C.person_id, C.observation_id as event_id, C.start_date, C.END_DATE,
       C.visit_occurrence_id, C.start_date as sort_date
from 
(
  select o.person_id,o.observation_id,o.observation_concept_id,o.visit_occurrence_id,o.value_as_number,o.observation_date as start_date, DATEADD(day,1,o.observation_date) as end_date , row_number() over (PARTITION BY o.person_id ORDER BY o.observation_date, o.observation_id) as ordinal
  FROM @cdm_database_schema.OBSERVATION o
JOIN #Codesets cs on (o.observation_concept_id = cs.concept_id and cs.codeset_id = 0)
) C

WHERE (C.start_date >= DATEFROMPARTS(2010, 1, 1) and C.start_date <= DATEFROMPARTS(2022, 12, 31))
AND C.ordinal = 1
-- End Observation Criteria

  ) E
	JOIN @cdm_database_schema.observation_period OP on E.person_id = OP.person_id and E.start_date >=  OP.observation_period_start_date and E.start_date <= op.observation_period_end_date
  WHERE DATEADD(day,365,OP.OBSERVATION_PERIOD_START_DATE) <= E.START_DATE AND DATEADD(day,0,E.START_DATE) <= OP.OBSERVATION_PERIOD_END_DATE
) P
WHERE P.ordinal = 1
-- End Primary Events
) pe
  
) QE

;

--- Inclusion Rule Inserts

select 0 as inclusion_rule_id, person_id, event_id
INTO #Inclusion_0
FROM 
(
  select pe.person_id, pe.event_id
  FROM #qualified_events pe
  
JOIN (
-- Begin Criteria Group
select 0 as index_id, person_id, event_id
FROM
(
  select E.person_id, E.event_id 
  FROM #qualified_events E
  INNER JOIN
  (
    -- Begin Correlated Criteria
select 0 as index_id, p.person_id, p.event_id
from #qualified_events p
LEFT JOIN (
SELECT p.person_id, p.event_id 
FROM #qualified_events P
JOIN (
  -- Begin Condition Occurrence Criteria
SELECT C.person_id, C.condition_occurrence_id as event_id, C.start_date, C.end_date,
  C.visit_occurrence_id, C.start_date as sort_date
FROM 
(
  SELECT co.person_id,co.condition_occurrence_id,co.condition_concept_id,co.visit_occurrence_id,co.condition_start_date as start_date, COALESCE(co.condition_end_date, DATEADD(day,1,co.condition_start_date)) as end_date 
  FROM @cdm_database_schema.CONDITION_OCCURRENCE co
  JOIN #Codesets cs on (co.condition_concept_id = cs.concept_id and cs.codeset_id = 1)
) C


-- End Condition Occurrence Criteria

) A on A.person_id = P.person_id  AND A.START_DATE <= DATEADD(day,-1,P.START_DATE) ) cc on p.person_id = cc.person_id and p.event_id = cc.event_id
GROUP BY p.person_id, p.event_id
HAVING COUNT(cc.event_id) = 0
-- End Correlated Criteria

  ) CQ on E.person_id = CQ.person_id and E.event_id = CQ.event_id
  GROUP BY E.person_id, E.event_id
  HAVING COUNT(index_id) = 1
) G
-- End Criteria Group
) AC on AC.person_id = pe.person_id AND AC.event_id = pe.event_id
) Results
;

SELECT inclusion_rule_id, person_id, event_id
INTO #inclusion_events
FROM (select inclusion_rule_id, person_id, event_id from #Inclusion_0) I;
TRUNCATE TABLE #Inclusion_0;
DROP TABLE #Inclusion_0;


select event_id, person_id, start_date, end_date, op_start_date, op_end_date
into #included_events
FROM (
  SELECT event_id, person_id, start_date, end_date, op_start_date, op_end_date, row_number() over (partition by person_id order by start_date ASC) as ordinal
  from
  (
    select Q.event_id, Q.person_id, Q.start_date, Q.end_date, Q.op_start_date, Q.op_end_date, SUM(coalesce(POWER(cast(2 as bigint), I.inclusion_rule_id), 0)) as inclusion_rule_mask
    from #qualified_events Q
    LEFT JOIN #inclusion_events I on I.person_id = Q.person_id and I.event_id = Q.event_id
    GROUP BY Q.event_id, Q.person_id, Q.start_date, Q.end_date, Q.op_start_date, Q.op_end_date
  ) MG -- matching groups

  -- the matching group with all bits set ( POWER(2,# of inclusion rules) - 1 = inclusion_rule_mask
  WHERE (MG.inclusion_rule_mask = POWER(cast(2 as bigint),1)-1)

) Results
WHERE Results.ordinal = 1
;



-- generate cohort periods into #final_cohort
select person_id, start_date, end_date
INTO #cohort_rows
from ( -- first_ends
	select F.person_id, F.start_date, F.end_date
	FROM (
	  select I.event_id, I.person_id, I.start_date, CE.end_date, row_number() over (partition by I.person_id, I.event_id order by CE.end_date) as ordinal
	  from #included_events I
	  join ( -- cohort_ends
-- cohort exit dates
-- By default, cohort exit at the event's op end date
select event_id, person_id, op_end_date as end_date from #included_events
    ) CE on I.event_id = CE.event_id and I.person_id = CE.person_id and CE.end_date >= I.start_date
	) F
	WHERE F.ordinal = 1
) FE;

select person_id, min(start_date) as start_date, end_date
into #final_cohort
from ( --cteEnds
	SELECT
		 c.person_id
		, c.start_date
		, MIN(ed.end_date) AS end_date
	FROM #cohort_rows c
	JOIN ( -- cteEndDates
    SELECT
      person_id
      , DATEADD(day,-1 * 0, event_date)  as end_date
    FROM
    (
      SELECT
        person_id
        , event_date
        , event_type
        , SUM(event_type) OVER (PARTITION BY person_id ORDER BY event_date, event_type ROWS UNBOUNDED PRECEDING) AS interval_status
      FROM
      (
        SELECT
          person_id
          , start_date AS event_date
          , -1 AS event_type
        FROM #cohort_rows

        UNION ALL


        SELECT
          person_id
          , DATEADD(day,0,end_date) as end_date
          , 1 AS event_type
        FROM #cohort_rows
      ) RAWDATA
    ) e
    WHERE interval_status = 0
  ) ed ON c.person_id = ed.person_id AND ed.end_date >= c.start_date
	GROUP BY c.person_id, c.start_date
) e
group by person_id, end_date
;

DELETE FROM @target_database_schema.@target_cohort_table where cohort_definition_id = @target_cohort_id;
INSERT INTO @target_database_schema.@target_cohort_table (cohort_definition_id, subject_id, cohort_start_date, cohort_end_date)
select @target_cohort_id as cohort_definition_id, person_id, start_date, end_date 
FROM #final_cohort CO
;






TRUNCATE TABLE #cohort_rows;
DROP TABLE #cohort_rows;

TRUNCATE TABLE #final_cohort;
DROP TABLE #final_cohort;

TRUNCATE TABLE #inclusion_events;
DROP TABLE #inclusion_events;

TRUNCATE TABLE #qualified_events;
DROP TABLE #qualified_events;

TRUNCATE TABLE #included_events;
DROP TABLE #included_events;

TRUNCATE TABLE #Codesets;
DROP TABLE #Codesets;
