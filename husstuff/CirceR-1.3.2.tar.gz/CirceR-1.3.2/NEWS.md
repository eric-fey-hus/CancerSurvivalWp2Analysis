CirceR 1.3.2
============

Update circe to v1.11.2
Update Site documentation.

CirceR 1.3.1
============

Update circe to v1.11.1
Update maven-clean-plugin from 3.1.0 to 3.3.1


CirceR 1.3.0
============

Introduced new function buildConceptSetQuery() and conceptSetExpressionFromJson to generate concept set queries from a concept set expression.

CirceR 1.2.1
============

Updated to Circe v1.10.1

CirceR 1.2.0
============

Updated to Circe v1.10.0


CirceR 1.1.1
============

Bug Fixes:
- Updated to Circe v1.6.4 to incorporate new fixes.

CirceR 1.1.0
============

New Features:
- Allows passing raw JSON to the buildCohortQuery() function.


CirceR 1.0.0
============

Initial version of the Circe R wrapper, wrapping version 1.9.0 of CIRCE.
- Includes functions for generating SQL and Markdown for a given cohort expression.
