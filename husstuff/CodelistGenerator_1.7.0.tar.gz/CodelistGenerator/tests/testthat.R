library(testthat)
library(CodelistGenerator)

test_check("CodelistGenerator")
