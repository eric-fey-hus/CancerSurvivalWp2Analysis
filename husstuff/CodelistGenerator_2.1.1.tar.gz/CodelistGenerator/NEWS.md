# CodelistGenerator 2.0.0
* Simplified the interface of getCandidateCodes, with a number of arguments removed.
* Added function summariseCohortCodeUse.

# CodelistGenerator 1.7.0
* Added function codesFromCohort.

# CodelistGenerator 1.6.0
* Improved getICD10StandardCodes function.
* Added function codesFromConceptSet.

# CodelistGenerator 1.5.0
* Require CDMConnector v1.0.0 or above.

# CodelistGenerator 1.4.0
* Added function summariseCodeUse.

# CodelistGenerator 1.3.0
* Added function getICD10StandardCodes.

# CodelistGenerator 1.2.0
* Added functions getATCCodes and getDrugIngredientCodes. 

# CodelistGenerator 1.1.0
* Added exactMatch and includeSequela options to getCandidateCodes function.

# CodelistGenerator 1.0.0
* Added a `NEWS.md` file to track changes to the package.
