#' @param cohortIds             A vector of one or more Cohort Ids.
