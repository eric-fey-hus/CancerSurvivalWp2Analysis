#' @param oracleTempSchema   DEPRECATED by DatabaseConnector: use \code{tempEmulationSchema} instead. 
