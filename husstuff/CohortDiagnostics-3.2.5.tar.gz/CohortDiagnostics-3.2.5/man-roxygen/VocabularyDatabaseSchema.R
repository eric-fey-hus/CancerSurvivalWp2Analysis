#' @param vocabularyDatabaseSchema   Schema name where your OMOP vocabulary data resides. This is 
#'                                   commonly the same as cdmDatabaseSchema. Note that for 
#'                                   SQL Server, this should include both the database and
#'                                   schema name, for example 'vocabulary.dbo'.
