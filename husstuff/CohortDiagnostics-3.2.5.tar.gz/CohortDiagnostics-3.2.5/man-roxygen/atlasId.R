#' @param atlasId      A vector of one Cohort Ids as in the source webApi/Atlas.
