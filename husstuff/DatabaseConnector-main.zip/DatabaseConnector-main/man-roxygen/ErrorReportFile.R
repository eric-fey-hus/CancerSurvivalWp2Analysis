#' @param errorReportFile        The file where an error report will be written if an error occurs.
#'                               Defaults to 'errorReportSql.txt' in the current working directory.
