#### SERVER ------
server <-	function(input, output, session) {
  
  # cdm snapshot------
  output$tbl_cdm_snaphot <- renderText(kable(snapshotcdm) %>%
                                         kable_styling("striped", full_width = F) )
  
  
  output$gt_cdm_snaphot_word <- downloadHandler(
    filename = function() {
      "cdm_snapshot.docx"
    },
    content = function(file) {
      x <- gt(snapshotcdm)
      gtsave(x, file)
    }
  )
  
  #database details
  output$tbl_database_details <- renderText(kable(database_details) %>%
                                              kable_styling("striped", full_width = F) )


  output$gt_database_details_word <- downloadHandler(
    filename = function() {
      "database_description.docx"
    },
    content = function(file) {
      x <- gt(database_details)
      gtsave(x, file)
    }
  )
  
  # patient_characteristics ----
  get_patient_characteristics <- reactive({
    
    validate(
      need(input$demographics_cohort_selector != "", "Please select a cohort")
    )
    
    validate(
      need(input$demographics_selector != "", "Please select a demographic")
    )
    
    patient_characteristics <- tableone_whole %>% 
      filter(strata_level %in% input$demographics_selector) %>% 
      filter(group_level %in% input$demographics_cohort_selector) %>% 
      filter(cdm_name %in% input$demographics_database_selector)

    patient_characteristics
  })
  
  
  output$gt_patient_characteristics  <- render_gt({
    PatientProfiles::gtCharacteristics(get_patient_characteristics())
  })  
  
  
  output$gt_patient_characteristics_word <- downloadHandler(
    filename = function() {
      "patient_characteristics.docx"
    },
    content = function(file) {
      
      gtsave(PatientProfiles::gtCharacteristics(get_patient_characteristics()), file)
    }
  )
  
  
  # clinical codelists ----------------
  get_codelists <- reactive({
    
    validate(
      need(input$codelist_cohort_selector != "", "Please select a cohort")
    )
    
    validate(
      need(input$codelist_vocab_selector != "", "Please select a vocab")
    )
    
    table <- concepts_lists %>%
      filter(Vocabulary %in% input$codelist_vocab_selector) %>%
      filter(Cancer %in% input$codelist_cohort_selector)
    
    table
    
  })
  

  output$tbl_codelists <- renderText(kable(get_codelists()) %>%
                                       kable_styling("striped", full_width = F) )


  output$gt_codelists_word <- downloadHandler(
    filename = function() {
      "concept_lists.docx"
    },
    content = function(file) {
      x <- gt(get_codelists())
      gtsave(x, file)
    }
  )
  
  
  # table one --------
  get_table_one <- reactive({
    
    validate(
      need(input$tableone_cohort_name_selector != "", "Please select a cohort")
    )
    
    validate(
      need(input$tableone_sex_selector != "", "Please select sex group")
    )
    
    validate(
      need(input$tableone_age_selector != "", "Please select age group")
    )
    
    validate(
      need(input$tableone_database_name_selector != "", "Please select a database")
    )

    table <- tableone_final %>%
      filter(Cancer %in% input$tableone_cohort_name_selector) %>%
      filter(Sex %in% input$tableone_sex_selector) %>%
      filter(Age %in% input$tableone_age_selector)

    selected_columns <- c("Description", input$tableone_database_name_selector)
    table <- table[, selected_columns, drop = FALSE]

    table

  })


  output$dt_tableone <- renderText(kable(get_table_one()) %>%
                                     kable_styling("striped", full_width = F) )


  output$gt_tableone_word <- downloadHandler(
    filename = function() {
      "table_one.docx"
    },
    content = function(file) {
      x <- gt(get_table_one())
      gtsave(x, file)
    }
  )
  

  # attrition --------
  get_attrition <- reactive({
    
    validate(
      need(input$attrition_cohort_name_selector1 != "", "Please select a cohort")
    )
    
    validate(
      need(input$attrition_database_name_selector1 != "", "Please select a database")
    )

    table <- attritioncdm %>%
      filter(Cancer %in% input$attrition_cohort_name_selector1) %>%
      filter(Database %in% input$attrition_database_name_selector1) 

    table

  })
  
  output$attrition_diagram <- renderGrViz({
    table <- get_attrition()
    validate(need(nrow(table) > 0, "No results for selected inputs"))
    render_graph(attritionChart(table))
  })
  
  output$cohort_attrition_download_figure <- downloadHandler(
    filename = function() {
      paste0(
        "cohort_attrition_", input$attrition_database_name_selector1, "_", 
        input$attrition_cohort_name_selector1, ".png"
      )
    },
    content = function(file) {
      table <- get_attrition()
      export_graph(
        graph = attritionChart(table),
        file_name = file,
        file_type = "png",
        width = input$attrition_download_width |> as.numeric()
      )
    }
  )


  output$dt_attrition <- renderText(kable(get_attrition()) %>%
                                kable_styling("striped", full_width = F) )


  output$gt_attrition_word <- downloadHandler(
    filename = function() {
      "cohort_attrition.docx"
    },
    content = function(file) {
      x <- gt(get_attrition())
      gtsave(x, file)
    }
  )

  # surv stats --------
  get_surv_est <- reactive({
    
    validate(
      need(input$surv_est_cohort_name_selector != "", "Please select a cohort")
    )
    
    validate(
      need(input$surv_est_sex_selector != "", "Please select sex group")
    )
    
    validate(
      need(input$surv_est_age_selector != "", "Please select age group")
    )
    
    validate(
      need(input$surv_est_database_name_selector != "", "Please select a database")
    )
    
    table <- med_surv_km %>%
      filter(Cancer %in% input$surv_est_cohort_name_selector) %>%
      filter(Database %in% input$surv_est_database_name_selector) %>% 
      filter(Age %in% input$surv_est_age_selector) %>% 
    filter(Sex %in% input$surv_est_sex_selector) %>% 
      select(-starts_with("upper_"), -starts_with("lower_")) %>% 
      select(-c(study_period)) %>% 
      mutate_all(~ ifelse(is.na(.), "-", .))
     
    
    table
    
  })
  
  output$dt_surv_est <- renderText(kable(get_surv_est()) %>%
                                      kable_styling("striped", full_width = F) )
  
  
  output$gt_surv_est_word <- downloadHandler(
    filename = function() {
      "survival_estimates.docx"
    },
    content = function(file) {
      x <- gt(get_surv_est())
      gtsave(x, file)
    }
  )  
  
  
  
  # surv risk table --------
  get_risk_table <- reactive({
    
    validate(
      need(input$risk_table_cohort_name_selector != "", "Please select a cohort")
    )
    
    validate(
      need(input$risk_table_sex_selector != "", "Please select sex group")
    )
    
    validate(
      need(input$risk_table_age_selector != "", "Please select age group")
    )
    
    validate(
      need(input$risk_table_database_name_selector != "", "Please select a database")
    )
    
    table <- survival_risk_table %>%
      filter(Cancer %in% input$risk_table_cohort_name_selector) %>%
      filter(Database %in% input$risk_table_database_name_selector) %>% 
      filter(Age %in% input$risk_table_age_selector) %>% 
      filter(Sex %in% input$risk_table_sex_selector)
    
    table
    
  })
  
  
  output$dt_risk_table <- renderText(kable(get_risk_table()) %>%
                                     kable_styling("striped", full_width = F) )
  
  
  output$gt_risk_table_word <- downloadHandler(
    filename = function() {
      "risk_table.docx"
    },
    content = function(file) {
      x <- gt(get_risk_table())
      gtsave(x, file)
    }
  )  
  
  
# survival plots -------
  get_surv_plot <- reactive({
    
    validate(
      need(input$survival_cohort_name_selector != "", "Please select a cohort")
    )
    validate(
      need(input$survival_database_selector != "", "Please select a database")
    )
    validate(
      need(input$survival_sex_selector != "", "Please select a sex")
    )
    validate(
      need(input$surv_plot_group != "", "Please select a group to colour by")
    )

    validate(
      need(input$surv_plot_facet != "", "Please select a group to facet by")
    )
    
      plot_data <- survival_km %>%
        filter(Database %in% input$survival_database_selector) %>%
        filter(Cancer %in% input$survival_cohort_name_selector) %>%
        filter(Age %in% input$survival_age_selector) %>%
        filter(Sex %in% input$survival_sex_selector)
    
    if (input$show_ci) {
      
      if (!is.null(input$surv_plot_group) && !is.null(input$surv_plot_facet)) {
        plot <- plot_data %>%
          unite("Group", c(all_of(input$surv_plot_group)), remove = FALSE, sep = "; ") %>%
          unite("facet_var", c(all_of(input$surv_plot_facet)), remove = FALSE, sep = "; ") %>%
          ggplot(aes(x = time, y = est, ymin = lcl, ymax = ucl, group = Group, colour = Group, fill = Group)) +
          geom_line() +
          geom_ribbon(aes(ymin = lcl, ymax = ucl, fill = Group, colour = Group), alpha = 0.3) +
          xlab("Time (Years)") +
          ylab("Survival Function (%)") +
          facet_wrap(vars(facet_var), ncol = 2) +
          theme_bw(base_size = 15) 
        
      } else if (!is.null(input$surv_plot_group) && is.null(input$surv_plot_facet)) {
        plot <- plot_data %>%
          unite("Group", c(all_of(input$surv_plot_group)), remove = FALSE, sep = "; ") %>%
          ggplot(aes(x = time, y = est, ymin = lcl, ymax = ucl, group = Group, colour = Group, fill = Group)) +
          geom_line() +
          geom_ribbon(aes(ymin = lcl, ymax = ucl, fill = Group, colour = Group), alpha = 0.3) +
          xlab("Time (Years)") +
          ylab("Survival Function (%)") +
          theme_bw(base_size = 15) 
        
      } else if (is.null(input$surv_plot_group) && !is.null(input$surv_plot_facet)) {
        plot <- plot_data %>%
          unite("facet_var", c(all_of(input$surv_plot_facet)), remove = FALSE, sep = "; ") %>%
          ggplot(aes(x = time, y = est, ymin = lcl, ymax = ucl, group = Group, colour = Group, fill = Group)) +
          geom_line() +
          geom_ribbon(aes(ymin = lcl, ymax = ucl, fill = Group, colour = Group), alpha = 0.3) +
          xlab("Time (Years)") +
          ylab("Survival Function (%)") +
          facet_wrap(vars(facet_var), ncol = 2) +
          theme_bw(base_size = 15) 
        
      } else {
        plot <- plot_data %>%
          ggplot(aes(x = time, y = est, ymin = lcl, ymax = ucl, group = Group, colour = Group, fill = Group)) +
          geom_line() +
          geom_ribbon(aes(ymin = lcl, ymax = ucl, fill = Group, colour = Group), alpha = 0.3) +
          xlab("Time (Years)") +
          ylab("Survival Function (%)") +
          theme_bw(base_size = 15) 
        
      }
      
      # Move scale_y_continuous outside of ggplot
      plot <- plot +
        scale_y_continuous(limits = c(0, NA),
                           labels = scales::percent,
                           expand = c(0.02,0.02)) +
        scale_x_continuous(expand = c(0.02,0.02),
                           breaks = pretty_breaks(n = 10)) +
        theme(strip.text = element_text(size = 15, face = "bold"))
      
      plot 
      
    } else {
      
      if (!is.null(input$surv_plot_group) && !is.null(input$surv_plot_facet)) {
        plot <- plot_data %>%
          unite("Group", c(all_of(input$surv_plot_group)), remove = FALSE, sep = "; ") %>%
          unite("facet_var", c(all_of(input$surv_plot_facet)), remove = FALSE, sep = "; ") %>%
          ggplot(aes(x = time, y = est, ymin = lcl, ymax = ucl, group = Group, colour = Group, fill = Group)) +
          geom_line() +
          xlab("Time (Years)") +
          ylab("Survival Function (%)") +
          facet_wrap(vars(facet_var), ncol = 2) +
          theme_bw(base_size = 15) 

        
      } else if (!is.null(input$surv_plot_group) && is.null(input$surv_plot_facet)) {
        plot <- plot_data %>%
          unite("Group", c(all_of(input$surv_plot_group)), remove = FALSE, sep = "; ") %>%
          ggplot(aes(x = time, y = est, ymin = lcl, ymax = ucl, group = Group, colour = Group, fill = Group)) +
          geom_line() +
          xlab("Time (Years)") +
          ylab("Survival Function (%)") +
          theme_bw(base_size = 15) 
        
      } else if (is.null(input$surv_plot_group) && !is.null(input$surv_plot_facet)) {
        plot <- plot_data %>%
          unite("facet_var", c(all_of(input$surv_plot_facet)), remove = FALSE, sep = "; ") %>%
          ggplot(aes(x = time, y = est, ymin = lcl, ymax = ucl, group = Group, colour = Group, fill = Group)) +
          geom_line() +
          xlab("Time (Years)") +
          ylab("Survival Function (%)") +
          facet_wrap(vars(facet_var), ncol = 2) +
          theme_bw(base_size = 15) 
        
      } else {
        plot <- plot_data %>%
          ggplot(aes(x = time, y = est, ymin = lcl, ymax = ucl, group = Group, colour = Group, fill = Group)) +
          geom_line() +
          xlab("Time (Years)") +
          ylab("Survival Function (%)") +
          theme_bw(base_size = 15) 
        
      }
      
      # Move scale_y_continuous outside of ggplot
          plot <- plot +
            scale_y_continuous(limits = c(0, NA),
                               labels = scales::percent,
                               expand = c(0.02,0.02)) +
            scale_x_continuous(expand = c(0.02,0.02),
                               breaks = pretty_breaks(n = 10)) +
            theme(strip.text = element_text(size = 15, face = "bold"))
                                        
      
      plot      
      
      
    }
    
    
  })
  
  output$survivalPlot <- renderPlot(
    get_surv_plot()
  )
  
  
  ### download survival plot ----
  output$survival_download_plot <- downloadHandler(
    filename = function() {
      "Survival_plot.png"
    },
    content = function(file) {
      ggsave(
        file,
        get_surv_plot(),
        width = as.numeric(input$survival_download_width),
        height = as.numeric(input$survival_download_height),
        dpi = as.numeric(input$survival_download_dpi),
        units = "cm"
      )
    }
  )
  
  # visualizations for sex and overall stratification
   get_surv_plot_sum <- reactive({
    validate(
      need(input$survivalsum_cohort_name_selector != "", "Please select a cohort")
    )
    validate(
      need(input$survivalsum_database_selector != "", "Please select a database")
    )
    validate(
      need(input$survivalsum_sex_selector != "", "Please select a sex")
    )
    validate(
      need(input$survsum_plot_group != "", "Please select a group to colour by")
    )
    validate(
      need(input$survsum_plot_facet != "", "Please select a group to facet by")
    )
    validate(
      need(input$survivalsum_variable_selector != "", "Please select a summary variable")
    )


    plot_data <- med_surv_km_sex_age %>%
      filter(Database %in% input$survivalsum_database_selector) %>%
      filter(Cancer %in% input$survivalsum_cohort_name_selector) %>%
      filter(Sex %in% input$survivalsum_sex_selector) %>%
      filter(Age %in% input$survivalsum_age_selector) %>% 
      filter(Variable %in% input$survivalsum_variable_selector) 

    if (!is.null(input$survsum_plot_group) && !is.null(input$survsum_plot_facet)) {
      
      plot <- plot_data %>%
        unite("Group", c(all_of(input$survsum_plot_group)), remove = FALSE, sep = "; ") %>%
        unite("facet_var", c(all_of(input$survsum_plot_facet)), remove = FALSE, sep = "; ") %>%
        ggplot(aes(x = Database, 
                   y = Value,
                   ymin = if (input$survivalsum_variable_selector == "One Year Survival") {
                     lower_1yrsurv
                   } else if (input$survivalsum_variable_selector == "Five Year Survival") {
                     lower_5yrsurv 
                   } else if (input$survivalsum_variable_selector == "Ten Year Survival") {
                     lower_10yrsurv   
                   } else if (input$survivalsum_variable_selector == "Restricted Mean") {
                     lower_rmean 
                   } else {
                     lower_medsurv
                   },
                   ymax = if (input$survivalsum_variable_selector == "One Year Survival") {
                     upper_1yrsurv
                   } else if (input$survivalsum_variable_selector == "Five Year Survival") {
                     upper_5yrsurv 
                   } else if (input$survivalsum_variable_selector == "Ten Year Survival") {
                     upper_10yrsurv   
                   } else if (input$survivalsum_variable_selector == "Restricted Mean") {
                     upper_rmean 
                   } else {
                     upper_medsurv
                   },
                   group = Group, 
                   colour = Group,
                   fill = Group)) +
        geom_errorbar(position = position_dodge(width = 0.6), width = 0, aes(color = Group), size = 1) +
        geom_point(position = position_dodge(width = 0.6), size = 2, shape = 21, stroke = 0.75, color = "black") +
        xlab("Database") +
        ylab(input$survivalsum_variable_selector) +
        facet_wrap(vars(facet_var), ncol = 2, scales = "free_y") +
        theme_bw(base_size = 15)
      
    } else if (!is.null(input$survsum_plot_group) && is.null(input$survsum_plot_facet)) {
      plot <- plot_data %>%
        unite("Group", c(all_of(input$survsum_plot_group)), remove = FALSE, sep = "; ") %>%
        ggplot(aes(x = Database, 
                   y = Value,
                   ymin = if (input$survivalsum_variable_selector == "One Year Survival") {
                     lower_1yrsurv
                   } else if (input$survivalsum_variable_selector == "Five Year Survival") {
                     lower_5yrsurv 
                   } else if (input$survivalsum_variable_selector == "Ten Year Survival") {
                     lower_10yrsurv   
                   } else if (input$survivalsum_variable_selector == "Restricted Mean") {
                     lower_rmean 
                   } else {
                     lower_medsurv
                   },
                   ymax = if (input$survivalsum_variable_selector == "One Year Survival") {
                     upper_1yrsurv
                   } else if (input$survivalsum_variable_selector == "Five Year Survival") {
                     upper_5yrsurv 
                   } else if (input$survivalsum_variable_selector == "Ten Year Survival") {
                     upper_10yrsurv   
                   } else if (input$survivalsum_variable_selector == "Restricted Mean") {
                     upper_rmean 
                   } else {
                     upper_medsurv
                   },
                   group = Group, 
                   colour = Group,
                   fill = Group)) +
        geom_errorbar(position = position_dodge(width = 0.6), width = 0, aes(color = Group), size = 1) +
        geom_point(position = position_dodge(width = 0.6), size = 2, shape = 21, stroke = 0.75, color = "black") +
        xlab("Database") +
        ylab(input$survivalsum_variable_selector) +
        theme_bw(base_size = 15)
      
    } else if (is.null(input$survsum_plot_group) && !is.null(input$survsum_plot_facet)) {
      plot <- plot_data %>%
        unite("facet_var", c(all_of(input$survsum_plot_facet)), remove = FALSE, sep = "; ") %>%
        ggplot(aes(x = Database, 
                   y = Value,
                   ymin = if (input$survivalsum_variable_selector == "One Year Survival") {
                     lower_1yrsurv
                   } else if (input$survivalsum_variable_selector == "Five Year Survival") {
                     lower_5yrsurv 
                   } else if (input$survivalsum_variable_selector == "Ten Year Survival") {
                     lower_10yrsurv   
                   } else if (input$survivalsum_variable_selector == "Restricted Mean") {
                     lower_rmean 
                   } else {
                     lower_medsurv
                   },
                   ymax = if (input$survivalsum_variable_selector == "One Year Survival") {
                     upper_1yrsurv
                   } else if (input$survivalsum_variable_selector == "Five Year Survival") {
                     upper_5yrsurv 
                   } else if (input$survivalsum_variable_selector == "Ten Year Survival") {
                     upper_10yrsurv   
                   } else if (input$survivalsum_variable_selector == "Restricted Mean") {
                     upper_rmean 
                   } else {
                     upper_medsurv
                   },
                   group = Group, 
                   colour = Group,
                   fill = Group)) +
        geom_errorbar(position = position_dodge(width = 0.6), width = 0, aes(color = Group), size = 1) +
        geom_point(position = position_dodge(width = 0.6), size = 2, shape = 21, stroke = 0.75, color = "black") +
        xlab("Database") +
        ylab(input$survivalsum_variable_selector) +
        facet_wrap(vars(facet_var), ncol = 2, scales = "free_y") +
        theme_bw(base_size = 15)
      
    } else {
      plot <- plot_data %>%
        ggplot(aes(x = Database, 
                   y = Value,
                   ymin = if (input$survivalsum_variable_selector == "One Year Survival") {
                     lower_1yrsurv
                   } else if (input$survivalsum_variable_selector == "Five Year Survival") {
                     lower_5yrsurv 
                   } else if (input$survivalsum_variable_selector == "Ten Year Survival") {
                     lower_10yrsurv   
                   } else if (input$survivalsum_variable_selector == "Restricted Mean") {
                     lower_rmean 
                   } else {
                     lower_medsurv
                   },
                   ymax = if (input$survivalsum_variable_selector == "One Year Survival") {
                     upper_1yrsurv
                   } else if (input$survivalsum_variable_selector == "Five Year Survival") {
                     upper_5yrsurv 
                   } else if (input$survivalsum_variable_selector == "Ten Year Survival") {
                     upper_10yrsurv   
                   } else if (input$survivalsum_variable_selector == "Restricted Mean") {
                     upper_rmean 
                   } else {
                     upper_medsurv
                   },
                   group = Group, 
                   colour = Group,
                   fill = Group)) +
        geom_errorbar(position = position_dodge(width = 0.6), width = 0, aes(color = Group), size = 1) +
        geom_point(position = position_dodge(width = 0.6), size = 2, shape = 21, stroke = 0.75, color = "black") +
        xlab("Database") +
        ylab(input$survivalsum_variable_selector) +
        theme_bw(base_size = 15)
    }

    # Move scale_y_continuous outside of ggplot
    plot <- plot +
      theme(strip.text = element_text(size = 15, face = "bold"),
            axis.text.x = element_text(angle = 45, hjust = 1))

    plot
  })
  
  
  output$survivalPlotSum <- renderPlot(
    get_surv_plot_sum()
  )
  
  ### download survival plot ----
  output$survivalsum_download_plot <- downloadHandler(
    filename = function() {
      "Survival_summary_plot.png"
    },
    content = function(file) {
      ggsave(
        file,
        get_surv_plot_sum(),
        width = as.numeric(input$survivalsum_download_width),
        height = as.numeric(input$survivalsum_download_height),
        dpi = as.numeric(input$survivalsum_download_dpi),
        units = "cm"
      )
    }
  ) 
  
  
  
   
}