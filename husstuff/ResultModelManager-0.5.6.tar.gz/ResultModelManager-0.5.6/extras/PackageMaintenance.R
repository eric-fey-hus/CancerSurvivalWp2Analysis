# see tests/testthat/helpers.R
devtools::load_all()
runPackageMaintenance()
