There are 2 changes and 1 bugfixes (see NEWS.md).

---

## Test environments
* Ubuntu 20.03, R 4.3.1
* Microsoft Windows Server 2019, R 4.3.1
* MacOS, R 4.3.1
* Windows 10, R 4.2.3

## R CMD check results

There were no ERRORs or WARNINGs. 

## Downstream dependencies

- Achilles, CohortAlgebra, DatabaseConnector, TreatmentPatterns, CDMConnector, CohortExplorer, and DrugExposureDiagnostics depend on SqlRender, and has been tested with this new version. No problems were found.